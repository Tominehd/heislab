 #include "fsm.h"

int returnState();
    
    /**
void state_machine(){

    while(1){
        switch(INIT){
            case INIT:


                
                break;

            case WAITING:
            case IDLE:
            case STOP:
            case OBSTRUCTION:
                
        }
    }

}

*/